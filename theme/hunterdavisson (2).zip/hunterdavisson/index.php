<?php get_header(); ?>

  <div class="page-header header-filter clear-filter" data-parallax="true" style="background-image: url('<?php bloginfo('template_url'); ?>/images/portland2.jpg');">
    <div class="container brandcontainer">
      <div class="row">
        <div class="col-md-10 ml-auto mr-auto">
          <div class="brand" >

        <div class="row">
                     <div class="col-md-6" >

                         <img class="img" src="<?php bloginfo('template_url'); ?>/images/Van.png" style='width: 100%; '>
                       </div>

                                <div class="col-md-6" >
            <h3><b>You’ve seen our green vans.
            </b></h3>
              <b>Contact us and discover why people have been calling us for their HVAC/R needs for over 50 years.</b>
<br/>
                <h3><b style='color: #2b4832'>24 Hour Service: 503-234-0477</b></h3>
  </div>
                </div>
                </div>
          </div><a id="dashboard1"></a>
        </div>
      </div>
    </div>
  </div>
  <div class="main main-raised">

    <div class="section section-tabs" style='background-color: #fff; padding: 30px''>
      <div class="container">
        <div class="row">

         <div class="col-md-8" >
           <p style='vertical-align: middle; margin-top: 30px'>

             <h2>Service and Maintenance</h2>
               HVAC and Refrigeration systems operate continuously to keep all types of structures comfortable and products at safe temperatures. Quality equipment can be expected to last a long time yet all equipment requires regular maintenance by professionals to keep everything operating at optimal efficiency.
              </p>
           </div>
           <div class="col-md-4">
          <div class="card card-blog" style='margin-top: 30px;  box-shadow: 0 0px 0px 0 rgba(0, 0, 0, 0.0), 0 0px 0px 0px rgba(0, 0, 0, 0.0), 0 0px 0px 0 rgba(0, 0, 0, 0.0)'>
          <div class="card-header card-header-image">
            <a >
              <img class="img" src="<?php bloginfo('template_url'); ?>/images/hvac.jpg">
              <div class="card-title">
                Service and Maintenance
              </div>
            </a>
          </div>
          </div>
            </div>
           </div><a id="dashboard2"></a>
           </div>

    </div>
    <div class="section section-tabs" style='background-color: #999; padding: 30px''>
      <div class="container">
        <div class="row">
       <div class="col-md-4">
      <div class="card card-blog" style='margin-top: 30px; box-shadow: 0 0px 0px 0 rgba(0, 0, 0, 0.0), 0 0px 0px 0px rgba(0, 0, 0, 0.0), 0 0px 0px 0 rgba(0, 0, 0, 0.0)'>
      <div class="card-header card-header-image">
        <a >
          <img class="img" src="<?php bloginfo('template_url'); ?>/assets/img/construction.jpg">
          <div class="card-title">
            Construction
          </div>
        </a>
      <div class="colored-shadow" style="background-image: url(&quot;<?php bloginfo('template_url'); ?>/assets/img/construction.jpg&quot;); opacity: 1;"></div></div>
      </div>
        </div>
         <div class="col-md-8" style="color: white">
           <p style='vertical-align: middle; color: white; margin-top: 30px'>
              <h2>Construction</h2>
               We don’t sacrifice quality when it comes to the parts we use or the technologies we employ. Building a project to your specifications is where your vision becomes reality and building from the ground up ensures that our standards will always exceed your expectations.
           </p>
           </div>
           </div>
           </div><a id="dashboard3"></a>
    </div>
    <div class="section section-tabs" style='background-color: #777; padding: 30px''>
      <div class="container">
        <div class="row">

         <div class="col-md-8" style="color: white" >
           <p style='vertical-align: middle; color: white !important; margin-top: 30px'>
             <h2>Design and Engineering</h2>
             Our engineering department has an exclusive team of seasoned professionals. This expertise in systems design, project management and in-house CAD capabilities gives you a substantial cost and performance advantage. We’ve developed a number of engineering strategies to bring even more efficiencies to every project.

           </p>
           </div> <div class="col-md-4">
           <div class="card card-blog" style='margin-top: 30px; box-shadow: 0 0px 0px 0 rgba(0, 0, 0, 0.0), 0 0px 0px 0px rgba(0, 0, 0, 0.0), 0 0px 0px 0 rgba(0, 0, 0, 0.0)'>
           <div class="card-header card-header-image">
             <a>
               <img class="img" src="<?php bloginfo('template_url'); ?>/assets/img/design.jpg">
               <div class="card-title">
                 Design and Engineering
               </div>
             </a>
           </div>
           </div>
             </div>
           </div>
           </div>
    </div>
<?php get_footer(); ?>
