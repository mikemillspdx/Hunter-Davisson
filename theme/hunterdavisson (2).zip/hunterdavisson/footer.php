
        <div class="section section-contacts" style=' background-color: #f2f2f2;  padding: 30px'>
            <div class="row">
                <div class="col-md-10 ml-auto mr-auto">
                  <div class="row">



              <div class="col-md-3 ">
                <h5 style='text-decoration: underline'>Contact Us</h5>
                <span class='footer-text'>  Hunter-Davisson, Inc.<br>
                  1800 S.E. Pershing Street<br>
                  Portland, OR 97202<br>

                  Phone: 503-234-0477<br>
                  Email: info@hunterdavisson.com</span>
              </div>
                <div class="col-md-3 ">

                    <h5 style='text-decoration: underline'>Hours</h5>
                    <span class='footer-text'>
                Regular Business Hours<br>
                Monday – Friday 7am – 4pm<br>

                Direct Service Line During Regular Hours<br>
                503-234-0477<br>
</span>
              </div>



                  <div class="col-md-4 ">
                    <form class="contact-form">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group bmd-form-group">
                        <label class="bmd-label-floating">Your Name</label>
                        <input type="email" class="form-control">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group bmd-form-group">
                        <label class="bmd-label-floating">Your Email</label>
                        <input type="email" class="form-control">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                  <div class="col-md-12">
                    <div class="form-group bmd-form-group">
                      <label class="bmd-label-floating">How did you hear about us?</label>
                      <input type="email" class="form-control">
                    </div>
                  </div>
                </div>



                  <div class="form-group bmd-form-group">
                    <label for="exampleMessage" class="bmd-label-floating">Your Message</label>
                    <textarea type="email" class="form-control" rows="4" id="exampleMessage"></textarea>
                  </div>
                  <div class="row">
                    <div class="col-md-4 ml-auto mr-auto text-center">
                      <button class="btn btn-success btn-raised">
                        Send Message
                      </button>
                    </div>
                  </div>
                </form>
              </div>

                                <div class="col-md-2 ml-auto mr-auto"></div>
            </div>
          </div>  </div>
          </div>
    </div>
  </div>
  <!--  End Modal -->
  <footer class="footer" data-background-color="black">
    <div class="container">
      <nav class="float-left">
        <ul>
          <li>
            <a href="/">
              Home
            </a>
          </li>
          <li>
            <a href="expertise.html?p=Commercial%20HVAC">
              Expertise
            </a>
          </li>
          <li>
            <a href="about.html?p=news">
              News
            </a>
          </li>
          <li>
            <a href="about.html?p=careers">
              Careers
            </a>
          </li>
          <li>
            <a href="contactus.html">
              Contact Us
            </a>
          </li>
          <li>
            <a href="">
              Site Map
            </a>
          </li>
          <li>
            <a href="">
              Terms and Conditions
            </a>
          </li>
        </ul>
      </nav>
      <div class="copyright float-middle">
        &copy;
        <script>
          document.write(new Date().getFullYear())
        </script> Hunter-Davisson, Inc.
      </div>
    </div>
  </footer>
  <!--   Core JS Files   -->
  <script src="<?php bloginfo('template_url'); ?>/assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="<?php bloginfo('template_url'); ?>/assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="<?php bloginfo('template_url'); ?>/assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="<?php bloginfo('template_url'); ?>/assets/js/plugins/moment.min.js"></script>
  <!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
  <script src="<?php bloginfo('template_url'); ?>/assets/js/plugins/bootstrap-datetimepicker.js" type="text/javascript"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="<?php bloginfo('template_url'); ?>/assets/js/plugins/nouislider.min.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <!--<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>-->
  <!--	Plugin for Tags, full documentation here: https://github.com/bootstrap-tagsinput/bootstrap-tagsinputs  -->
  <script src="<?php bloginfo('template_url'); ?>/assets/js/plugins/bootstrap-tagsinput.js"></script>
  <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="<?php bloginfo('template_url'); ?>/assets/js/plugins/bootstrap-selectpicker.js" type="text/javascript"></script>
  <!--	Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="<?php bloginfo('template_url'); ?>/assets/js/plugins/jasny-bootstrap.min.js" type="text/javascript"></script>
  <!--	Plugin for Small Gallery in Product Page -->
  <script src="<?php bloginfo('template_url'); ?>/assets/js/plugins/jquery.flexisel.js" type="text/javascript"></script>
  <!-- Plugins for presentation and navigation  -->
  <script src="<?php bloginfo('template_url'); ?>/assets/demo/modernizr.js" type="text/javascript"></script>
  <script src="<?php bloginfo('template_url'); ?>/assets/demo/vertical-nav.js" type="text/javascript"></script>
  <!-- Place this tag in your head or just before your close body tag. -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Js With initialisations For Demo Purpose, Don't Include it in Your Project -->
  <script src="<?php bloginfo('template_url'); ?>/assets/demo/demo.js" type="text/javascript"></script>
  <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
  <script src="<?php bloginfo('template_url'); ?>/assets/js/material-kit.js?v=2.2.0" type="text/javascript"></script>




<?php wp_footer(); // js scripts are inserted using this function ?>

<!-- Crazy Egg -->
  <script type="text/javascript">
setTimeout(function(){var a=document.createElement("script");
var b=document.getElementsByTagName("script")[0];
a.src=document.location.protocol+"//dnn506yrbagrg.cloudfront.net/pages/scripts/0017/4064.js?"+Math.floor(new Date().getTime()/3600000);
a.async=true;a.type="text/javascript";b.parentNode.insertBefore(a,b)}, 1);
</script>


</body>

</html>
