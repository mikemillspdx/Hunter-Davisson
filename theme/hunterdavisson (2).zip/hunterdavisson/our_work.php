<?php
/*
Template Name: Our Work
*/
?>


<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap clearfix">

					<?php get_sidebar(); // sidebar 1 ?>

					<div id="main" class="eightcol clearfix" role="main">

						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

						<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

						<header>

							<h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>

						</header> <!-- end article header -->

						<section class="post-content clearfix" itemprop="articleBody">
							<?php the_content(); ?>

							<div class="tile-container">
							<?php
							$pages = get_pages( array('child_of'=>$post->ID, 'sort_column' => 'menu_order') );
							foreach($pages as $page){?>

							<div class="work-box">
							<a href="<?php echo get_permalink($page->ID); ?>" title="<?php the_title(); ?>">
							<img src="<?php the_field('featured_image', $page->ID);?>" alt="featured image" />
							<h2><?php echo get_the_title($page->ID); ?></h2>
							</a>
							</div>

							<?php };?>

     						</div>

					</section> <!-- end article section -->


					</article> <!-- end article -->

						<?php endwhile; else: ?>

						<article id="post-not-found">
						    <header>
						    	<h1>Not Found</h1>
						    </header>
						    <section class="post-content">
						    	<p>Sorry, but the requested resource was not found on this site.</p>
						    </section>
						    <footer>
						    </footer>
						</article>

						<?php endif; ?>

					</div> <!-- end #main -->

				</div> <!-- end #inner-content -->

				</div> <!-- end #content -->

			<div class="push"></div>
			</div><!--container-->
				<?php get_footer(); ?>
