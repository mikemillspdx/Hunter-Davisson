<?php
/*
Template Name: Sitemap
*/
?>
<?php get_header(); ?>

<div id="content">
	<div id="inner-content" class="wrap clearfix">
	<?php get_sidebar(); // sidebar 1 ?>
		<div id="main" class="eightcol clearfix" role="main">
			<h1><?php the_title(); ?></h1>
			<ul class="post-content"><?php wp_nav_menu('menu=Sitemap'); ?></ul>


    		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    		<?php the_content(__('Read more'));?>
    		<?php endwhile; else: ?>

  			  <p><strong>There has been a glitch in the Matrix.</strong><br />
     			 There is nothing to see here.</p>
    			<p>Please try somewhere else.</p>
		    <?php endif; ?>

		</div>
	</div>
</div>
<!-- end #content-->
<div class="push"></div>
				</div><!--container-->
<?php get_footer(); ?>
