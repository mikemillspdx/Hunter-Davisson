<?php
/*
Template Name: file upload
*/
?>

<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap clearfix">

					<?php get_sidebar(); // sidebar 1 ?>

					<div id="main" class="eightcol clearfix" role="main">

					<?php if(is_user_logged_in()){ ?>
						<a class="logout-link" href="<?php echo wp_logout_url(home_url()); ?>">Logout</a>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

						<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

						<header>

							<h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>

						</header> <!-- end article header -->

						<section class="post-content clearfix" itemprop="articleBody">

							<?php

								function remove_form_entry($entry) {
								    global $wpdb;

								    $lead_id = $entry;

								    //Delete from lead details
								    $sql = $wpdb->prepare("DELETE FROM wp_rg_lead_detail WHERE lead_id=%d", $lead_id);
								    $wpdb->query($sql);

								    //Delete from lead
								    $sql = $wpdb->prepare("DELETE FROM wp_rg_lead WHERE id=%d", $lead_id);
								    $wpdb->query($sql);

								}

							     if($_POST['submit']) {

							           $delete_lead_id = $_POST['delete_lead_id'];

							           remove_form_entry($delete_lead_id);

							     }

							     /*function end_section($i) {

							     	echo "<h3>" . $i . "</h3>";
							     	echo $ahtml;
							     	echo "</ul>";
							     	$ahtml = "";
							     	return $ahtml;
							     }*/


							?>



							<?php

							// get logged in user role
							$role = strtolower(get_user_role());

							// get logged in user id
							global $current_user;
							$current_user = wp_get_current_user();
							$user_ID = $current_user->ID;
							$file_heading = '';



							//get logged in user user group name
							global $userAccessManager;
							if (isset($userAccessManager)) {
							    $userId = $user_ID;
							    $uamAccessHandler = $userAccessManager->getAccessHandler();
							    $userGroupsForUser = $uamAccessHandler->getUserGroupsForObject('user', $userId);

							    foreach($userGroupsForUser as $element){
							         // $ugroup = $element->getId();
							         $ugroup = $element->getgroupName();
							    }
							}



							echo "<h3>" . $ugroup . " Files</h3>";



							// get form values and display depending on logged in user
							$form_id = 2;
							$sort_field_number = 5;
							$sort_direction='ASC';
							$leads = RGFormsModel::get_leads($form_id, $sort_field_number, $sort_direction);
							$headline = "";


							//echo "<ul>";

							foreach($leads as $lead) {


							$lid = $lead['id'];
							$lurl = $lead[2];
							$lname = $lead[3];
							$lnotes = $lead[4];
							$lugroup = $lead[5];

							$delete_form = "<form class='file-delete-form' method='post' action='' onsubmit='return confirm(\"Do you really want to delete this record?\");'><input type='Submit' name='submit' value='Delete'> <input type='hidden' name='delete_lead_id' value='" . $lid . "'></form>";


							if ($lnotes != "") {
								$lnotes = ": " . $lnotes;
							}
							//if ($lugroup == $ugroup || $role == "administrator" || $role == "file_upload_manager") {
							if ($lugroup == $ugroup) {
							 	$ahtml .= "<li><a href='" . $lurl . "' target='_blank'>" . $lname . "</a>" . $lnotes . "</li>";
							}


							if ($role == "administrator" || $role == "file_upload_manager") {

								if($headline != $lugroup) {
									if ($ahtml != "") {
										echo "<ul>" . $ahtml . "</ul>";
									}
									$headline = $lugroup;
									echo "<h4>" . $headline . "</h4>";
									$ahtml = "";

								}


								$ahtml .= "<li><a href='" . $lurl . "' target='_blank'>" . $lname . "</a>" . $lnotes . " " . $delete_form . "</li>";


							}

							}

							echo "<ul>" . $ahtml . "</ul>";



							echo "<br /><br /><h3>Upload A New File</h3>";


							if ($role == "administrator" || $role == "file_upload_manager") {


								 ?>

								 <script type="text/javascript">


								 	jQuery(document).ready(function(){

								 		// set default value
								 		jQuery("#input_2_5").val('User Group A');


								 		jQuery('#usergroups').change(function() {
								 			var ug = jQuery('#usergroups').val();
								 			jQuery("#input_2_5").val(ug);
								 		});


								 	});





								 </script>


								 <span><strong>Please select User Group</strong></span>




								 <?php

								 	global $userAccessManager;
								 	$uamUserGroups = $userAccessManager->getAccessHandler()->getUserGroups();


								 	if (isset($uamUserGroups)) {

								 		echo "<select id='usergroups'>";
								 	        foreach ($uamUserGroups as $uamUserGroup) {


								 	        echo $uamUserGroup->getGroupName();

								 	        echo "<option value='" . $uamUserGroup->getGroupName() . "'>" . $uamUserGroup->getGroupName() . "</option>";

								 	        }

								 	    echo "</select>";
								 	    }

								 ?>






								 <?php
							}
								  echo do_shortcode('[gravityform id="2" name="File Upload" title="false" description="false" ajax="false" field_values=\'user_group='. $ugroup .'\' ]');

							    ?>


						</section> <!-- end article section -->


					</article> <!-- end article -->


						<?php endwhile; ?>

						<?php else : ?>

						<article id="post-not-found">
						    <header>
						    	<h1>Not Found</h1>
						    </header>
						    <section class="post-content">
						    	<p>Sorry, but the requested resource was not found on this site.</p>
						    </section>
						    <footer>
						    </footer>
						</article>

						<?php endif; ?>

					<?php } else {  // user logged in ?>
						<h1 class="page-title">File Upload</h1>
						<h3>Welcome to the Hunter Davisson File Upload system.</h3>
						<div class="bf_login_section">
							<p><strong>Please login to continue.</strong></p>
							<?php
								wp_login_form(array('redirect' => site_url('/file-upload/')));
							?>
						</div>
					<?php } ?>

					</div> <!-- end #main -->

				</div> <!-- end #inner-content -->

				</div> <!-- end #content -->

				<div class="push"></div>
				</div><!--container-->
				<?php get_footer(); ?>
