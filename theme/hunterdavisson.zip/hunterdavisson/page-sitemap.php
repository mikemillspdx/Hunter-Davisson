<?php
/*
Template Name: Sitemap
*/
?>
<?php get_header(); ?>
<div class="subpage-header page-header header-filter clear-filter"  data-parallax="true" style="background-image: url('<?php echo get_random_header(bloginfo('template_url')); ?>');">
        <div class="container">
         <div class="row">
           <div class="col-md-12">
             <h1 style='color: white'><?php the_title(); ?></h1>
           </div>
         </div>
       </div>
      </div>
  </div>
  <div class="main main-raised">


		    <div class="container"  style='padding-top: 40px; padding-bottom: 100px'>
			<h1><?php the_title(); ?></h1>
			<ul class="post-content"><?php wp_nav_menu('menu=Sitemap'); ?></ul>


    		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    		<?php the_content(__('Read more'));?>
    		<?php endwhile; else: ?>

  			  <p><strong>There has been a glitch in the Matrix.</strong><br />
     			 There is nothing to see here.</p>
    			<p>Please try somewhere else.</p>
		    <?php endif; ?>
<!-- end #content-->
<div class="push"></div>
				</div><!--container-->
<?php get_footer(); ?>
