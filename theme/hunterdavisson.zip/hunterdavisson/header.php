
<!DOCTYPE html>
<html <?php language_attributes(); ?>/>

<head>
  <meta charset="<?php bloginfo('charset'); ?>/" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?php bloginfo('template_url'); ?>/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="<?php bloginfo('template_url'); ?>/assets/img/favicon.ico">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Hunter-Davisson has been designing, installing and servicing commercial heating, cooling, controls and refrigeration systems for over 50 years in Portland & the Pacific Northwest.
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="<?php bloginfo('template_url'); ?>/assets/css/material-kit.css?v=2.2.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?php bloginfo('template_url'); ?>/assets/demo/demo.css" rel="stylesheet" />
  <link href="<?php bloginfo('template_url'); ?>/assets/demo/vertical-nav.css" rel="stylesheet" />
  <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" />
  <link href="<?php bloginfo('template_url'); ?>/carousel.css" rel="stylesheet" />
</head>

<body class="index-page sidebar-collapse" style='padding-top: 0px'>

  <nav class="navbar navbar-color-on-scroll navbar-transparent navbar-transparent2 fixed-top  navbar-expand-lg " color-on-scroll="100" id="sectionsNav">
    <a href="index.html"><img src='<?php bloginfo('template_url'); ?>/images/logo.png' class='hunterlogo'/></a>
    <div class="container">
      <div class="navbar-translate">
        <a class="navbar-brand" href=<?php bloginfo('template_url'); ?>/index.html"><a href="#"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="sr-only">Toggle navigation</span>
          <span class="navbar-toggler-icon"></span>
          <span class="navbar-toggler-icon"></span>
          <span class="navbar-toggler-icon"></span>
        </button>
      </div>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav ml-auto">
          <li class="dropdown nav-item">
            <a href="service.html" class="dropdown-toggle nav-link" data-toggle="dropdown" >
              <i class="material-icons"  >apps</i> Services
            </a>
            <div class="dropdown-menu dropdown-with-icons">
              <a href="service.html?p=design" class="dropdown-item">Design and Engineering
              </a>
              <a href="service.html?p=construction" class="dropdown-item">Construction
              </a>
              <a href="service.html?p=service" class="dropdown-item">
                Service and Maintenance
              </a>
            </div>
          </li>
          <li class="dropdown nav-item">
            <a href="expertise.html" class="dropdown-toggle nav-link" data-toggle="dropdown" >
              <i class="material-icons" >dashboard</i> Expertise
            </a>
            <div class="dropdown-menu dropdown-with-icons">
              <a class="dropdown-item" href="expertise.html?p=Commercial HVAC">Commercial HVAC</a>
              <a class="dropdown-item" href="expertise.html?p=Commercial Controls">Commercial Controls</a>
              <a class="dropdown-item" href="expertise.html?p=Commercial Refrigeration">Commercial Refrigeration</a>
            </div>
          </li>
          <li class="dropdown nav-item">
            <a href="portfolio.html" class="nav-link" >
              <i class="material-icons"  >layers</i> Portfolio
            </a>

          </li>

          <li class="dropdown nav-item">
            <a href="about.html"" class="dropdown-toggle nav-link" data-toggle="dropdown" >
              <i class="material-icons"  >account_circle</i> About Us
            </a>
            <div class="dropdown-menu dropdown-with-icons">
              <a class="dropdown-item" href="about.html?p=history">History</a>
              <a class="dropdown-item" href="about.html?p=leadership">Executive Leadership</a>
              <a class="dropdown-item" href="about.html?p=maintenance">Service & Maintenance</a>
              <a class="dropdown-item" href="about.html?p=sales">Sales & Engineering</a>
              <a class="dropdown-item" href="about.html?p=aboutconstruction">Construction</a>
              <a class="dropdown-item" href="about.html?p=support">Support</a>
              <a class="dropdown-item" href="about.html?p=community">Community</a>
              <a class="dropdown-item" href="about.html?p=news">News</a>
              <a class="dropdown-item" href="about.html?p=careers">Careers</a>
            </div>
          </li>

          <li class="dropdown nav-item">
            <a href="resources.html" class="nav-link">
              <i class="material-icons"  >settings</i> Resources
            </a>

          </li>
          <li class="dropdown nav-item">
            <span class="nav-link"><i>24 Hour Service: 503-234-0477</i></span>
          </li>
        </ul>
      </div>
    </div>
  </nav>
