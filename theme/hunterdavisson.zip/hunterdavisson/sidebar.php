<div id="sidebar1" class="sidebar fourcol last clearfix" role="complementary">

<div id="sidebar-menu-container">
<?php

    // GET PARENT ID AND CHILD PAGES LIST

  if ($post->post_parent) {

        $ancestors=get_post_ancestors($post->ID);

        $root=count($ancestors)-1;

        $parent = $ancestors[$root];

  } else {

        $parent = $post->ID;

  }

    $children = wp_list_pages("depth=2&title_li=&child_of=". $parent ."&echo=0");

  ?>

<div class="sidebar-top">

  <!-- SHOW TOP-LEVEL PARENT TITLE -->

<?php

      if (!is_category() && !is_home() && !is_single()){

      if(!$parent) {
            $title = get_the_title();
        } else {
            $title = get_the_title($parent);
      }

      echo '<h2 class="title"><a href="'. get_permalink($parent) .'">' . $title . '</a></h2>';
          }


  ?>

  <?php if (is_category()) : ?>

        <h2 class="title"><?php single_cat_title(); ?></h2>

        <?php endif;?>

            <?php if (is_home()) { ?>

    <h2 class="title">News</h2>

  <?php }?>

<?php if(is_single()) {
        echo '<h2 class="title"><a href="/news/">Back to News</a></h2>';

  }
  ?>

 </div>




  <!-- SHOW CHILDREN NAV -->

  <?php

     // if there are children and the page template is not our_work.php or several page ids

      if ($children && !is_page_template( 'our_work.php' )  ) {

          echo "<div class='sidebar-first-inner'>";
            echo "<ul>". $children . "</ul>";
            echo "</div>"; //sidebar first inner
      }

   // if this is our_work.php and several other page ids, print out the following
   //trying to follow the client's wishes, making the portfolio page sidebar something tag based or whatever.

   if(is_page_template( 'our_work.php' ) || is_page( array( 422, 489, 424, 427, 429 ) ) ) {

      echo "<div class='sidebar-first-inner'>";
    echo "</div>"; //sidebar first inner

  }

  $this_single_id = get_the_ID();
   //this isn't quite working. Not able to get the current id.....
  if(is_single () || is_home() || $this_single_id != $post->ID){

   echo "<div class='sidebar-first-inner'>";
   echo '<ul>';
    $args = array( 'numberposts' => '5' );
  $recent_posts = wp_get_recent_posts($args);
    foreach( $recent_posts as $recent ){
      echo '<li><a href="' . get_permalink($recent["ID"]) . '"title='.esc_attr($recent["post_title"]).'" >' .   $recent["post_title"].'</a> </li> ';
    }
  echo '</ul>';
  echo "</div>"; //sidebar first inner

}

  ?>



<div class="sidebar-bottom"></div>

</div><!--sidebar-menu-container-->

<div id="sidebar-content">

<?php

if (!is_page(15)){
  //sidebar text
    $textblock = get_field("sidebar_text");

  if(!$textblock) $textblock = get_field("sidebar_text", "options");

  if($textblock != "") {
    echo '<div class="text-box">';

        echo $textblock;

        echo '</div>';
        }




         //	Linking to a page
  $link = get_field("link_to_a_page");

  if(!$link) $link = get_field("page_link", "options");

  if($link != "") {

    echo '<div class="content-link">';

            echo '<a href="'. $link .'" >Contact Us</a>';


          echo '</div>';

          }
  }
          echo '<div class="quote-box">';



        $quotes = get_field("testimonials");

        if(!$quotes) $quotes = get_field("testimonials", "options");


              echo '<ul id="quote-list">';

          foreach($quotes as $quote) {

          echo '<li>'. $quote["client_testimonial"] . '<span class="quote">'. $quote["author"] . '</span>' . '</li>';

          }

          echo "</ul>";

              echo "</div>";

  ?>

</div><!--sidebar-content-->

</div>
