
<?php get_header(); ?>
<div class="page-header subpage-header header-filter clear-filter"  data-parallax="true" style="background-image: url('<?php bloginfo('template_url'); ?>/images/tillicum3.jpg');">
        <div class="container">
         <div class="row">
           <div class="col-md-12">
             <h1 style='color: white'><?php the_title(); ?></h1>
           </div>
         </div>
       </div>
      </div>
  </div>
  <div class="main main-raised">

				    <div class="container"  style='padding-top: 40px; padding-bottom: 100px'>

						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

						<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

						<header>

							<h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>

							<p class="meta"><?php _e("Posted", "bonestheme"); ?> <time datetime="<?php echo the_time('Y-m-j'); ?>" pubdate><?php the_time('F jS, Y'); ?></time> </p>

						</header> <!-- end article header -->

						<section class="post-content clearfix" itemprop="articleBody">
							<?php the_content(); ?>


						</section> <!-- end article section -->

						<footer>

							<?php the_tags('<p class="tags"><span class="tags-title">Tags:</span> ', ', ', '</p>'); ?>

						</footer> <!-- end article footer -->



					</article> <!-- end article -->

						<?php endwhile; ?>

						<?php else : ?>

						<article id="post-not-found">
						    <header>
						    	<h1>Not Found</h1>
						    </header>
						    <section class="post-content">
						    	<p>Sorry, but the requested resource was not found on this site.</p>
						    </section>
						    <footer>
						    </footer>
						</article>

						<?php endif; ?>
		<div class="push"></div>
	</div><!--container-->
</div></div>
<?php get_footer(); ?>
