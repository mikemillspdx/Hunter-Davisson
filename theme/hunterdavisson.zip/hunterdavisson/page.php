
<?php get_header(); ?>
<div class="page-header subpage-header header-filter clear-filter"  data-parallax="true" style="background-image: url('<?php bloginfo('template_url'); ?>/images/tillicum3.jpg');">
        <div class="container">
         <div class="row">
           <div class="col-md-12">
             <h2  id="title" class="title"><?php the_title(); ?></h2>
           </div>
         </div>
       </div>
      </div>
  </div>
  <div class="main main-raised">


		    <div class="container"  style='padding-top: 40px'>
			<div id="content">

				<div id="inner-content" >

					<div id="main"  role="main">

						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

						<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

						<header>

							<h2 class="page-title" itemprop="headline"><?php the_title(); ?></h2>

						</header> <!-- end article header -->

						<section class="post-content clearfix" itemprop="articleBody">
							<?php the_content(); ?>



						</section> <!-- end article section -->


					</article> <!-- end article -->


						<?php endwhile; ?>

						<?php else : ?>

						<article id="post-not-found">
						    <header>
						    	<h1>Not Found</h1>
						    </header>
						    <section class="post-content">
						    	<p>Sorry, but the requested resource was not found on this site.</p>
						    </section>
						    <footer>
						    </footer>
						</article>

						<?php endif; ?>

					</div> <!-- end #main -->

				</div> <!-- end #inner-content -->

				</div> <!-- end #content -->

				<div class="push"></div>
				</div><!--container-->
				</div>
				<?php get_footer(); ?>
