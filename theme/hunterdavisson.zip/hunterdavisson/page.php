
<?php get_header(); ?>
<div class="subpage-header page-header header-filter clear-filter"  data-parallax="true" style="background-image: url('<?php echo get_random_header(bloginfo('template_url')); ?>');">
        <div class="container">
         <div class="row">
           <div class="col-md-12">
             <h1 style='color: white'><?php the_title(); ?></h1>
           </div>
         </div>
       </div>
      </div>
  </div>
  <div class="main main-raised">


		    <div class="container"  style='padding-top: 40px; padding-bottom: 100px'>
			<div id="content">

				<div id="inner-content" >

					<div id="main"  role="main">

						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

						<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

						<header>

							<h2 class="page-title" itemprop="headline"><?php the_title(); ?></h2>

						</header> <!-- end article header -->

						<section class="post-content clearfix" itemprop="articleBody">
							<?php the_content(); ?>



						</section> <!-- end article section -->


					</article> <!-- end article -->


						<?php endwhile; ?>

						<?php else : ?>

						<article id="post-not-found">
						    <header>
						    	<h1>Not Found</h1>
						    </header>
						    <section class="post-content">
						    	<p>Sorry, but the requested resource was not found on this site.</p>
						    </section>
						    <footer>
						    </footer>
						</article>

						<?php endif; ?>

					</div> <!-- end #main -->

				</div> <!-- end #inner-content -->

				</div> <!-- end #content -->

				<div class="push"></div>
				</div><!--container-->
				</div>
				<?php get_footer(); ?>
