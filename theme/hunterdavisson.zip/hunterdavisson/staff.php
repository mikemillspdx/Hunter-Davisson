<?php
/*
Template Name: Staff Page
*/
?>

<?php get_header(); ?>
<div class="page-header subpage-header header-filter clear-filter"  data-parallax="true" style="background-image: url('<?php bloginfo('template_url'); ?>/images/tillicum3.jpg');">
        <div class="container">
         <div class="row">
           <div class="col-md-12">
             <h1 style='color: white'><?php the_title(); ?></h1>
           </div>
         </div>
       </div>
      </div>
  </div>
  <div class="main main-raised">

				    <div class="container"  style='padding-top: 40px; padding-bottom: 100px'>

              <div class="section section-tabs" style='  padding: 30px'>
                <div class="container">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


								<h2><?php the_title(); ?></h2>


    				<div class="row">
					<?php

							$bios = get_field("staff_biographies");

		      		       if ($bios){

		      	            $i = 1;
		                 	foreach($bios as $bio) {

		      		    	$portrait_thumb = wp_get_attachment_image_src($bio["portait"], "sidebar_image");
					    	$portrait_thumb = $portrait_thumb[0];

                         	$name = $bio["name"];


												echo '<div class="col-md-4">';
												echo '<div class="card card-blog" style="margin-top: 30px; box-shadow: 0 0px 0px 0 rgba(0, 0, 0, 0.0), 0 0px 0px 0px rgba(0, 0, 0, 0.0), 0 0px 0px 0 rgba(0, 0, 0, 0.0)">';
												echo '<div class="card-header card-header-image"  data-toggle="modal" data-target="#myModal'. $i++. '">';
													echo '<a>';
														echo '<img class="img" src="'. $portrait_thumb .'">';
														echo '<div class="card-title">';
															echo $name . '<br/>'. $bio['job_title'];
														echo '</div>';
													echo '</a>';
												echo '</div>';
												echo '</div>';
												echo '</div>';

                             	}
		      				}

		      				?>


							<!-- MODAL WINDOW -->
				 	<?php

					$popups = get_field("staff_biographies");

		      		if ($popups){

		      		    $i = 1;
		      		    foreach($popups as $popup) {

		      		    	$color_portrait = wp_get_attachment_image_src($popup["color_portait"], "sidebar_image");
					    	$color_portrait = $color_portrait[0];

                         	$name = $popup["name"];


													  echo '<div class="modal fade" id="myModal'. $i++ .'" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">';
    echo '<div class="modal-dialog" role="document">';
      echo '<div class="modal-content">';
        echo '<div class="modal-header">';
          echo '<button type="button" class="close" data-dismiss="modal" aria-label="Close" >';
            echo '<i class="material-icons">clear</i>';
          echo '</button>';
        echo '</div>';
        echo '<div class="modal-body">';
            echo '<div class="container">';
              echo '<div class="row">';
             echo '<div class="col-md-5">';
						 if ($color_portrait) {
		 				 			echo '<img style="width: 100%" src="'. $color_portrait .'" alt="'. $name . '" /> ';
			 	 		}
            echo ' </div>';
            echo '<div class="col-md-7">';
						echo '<h2>'. $name . '</h2>';
						echo '<p class="job-title">'. strip_tags($popup ['job_title']) .'</p>';
						echo  $popup ['biography'] ;
          echo '</div>';
          echo '</div>';
          echo '</div>';



        echo '</div>';
        echo '<div class="modal-footer">';
          echo '<button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>';
        echo '</div>';
      echo '</div>';
    echo '</div>';
  echo '</div>';
                             	}


		      				}
					?>
						<!-- END MODAL WINDOW -->

						       </div>



						<?php endwhile; ?>

						<?php else : ?>


						<?php endif; ?>

	</div><!--container-->

  	</div></div>
	</div></div>
<?php get_footer(); ?>
