<?php
/*
Template Name: Staff Page
*/
?>

<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap clearfix">

			<?php get_sidebar(); // sidebar 1 ?>


					<div id="main" class="eightcol clearfix" role="main">

						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

						<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article">

							<header>

								<h1 class="page-title"><?php the_title(); ?></h1>

							</header> <!-- end article header -->

							<section class="post-content">
					<?php

							$bios = get_field("staff_biographies");

		      		       if ($bios){

		      	            $i = 1;
		                 	foreach($bios as $bio) {

		      		    	$portrait_thumb = wp_get_attachment_image_src($bio["portait"], "sidebar_image");
					    	$portrait_thumb = $portrait_thumb[0];

                         	$name = $bio["name"];


                            echo '<a class="staff" href="#dialog-'. $i++ . '" name="modal">';

                            echo '<div class="portrait-thumbnail">';

		      				echo '<img class="thumb" src="'. $portrait_thumb .'" alt="'. $name . '" /> ';

		      				echo '<div class="name-wrapper">';
		      				echo '<h2>'. $name . '</h2>';

		      				echo '<p class="job-title">'. $bio['job_title'] .'</p>';

		      				echo '</div>';

                            echo '</div>'; #protrait thumbnail

                            echo '</a>';

                             	}
		      				}

		      				?>


							<!-- MODAL WINDOW -->
				 	<?php

					$popups = get_field("staff_biographies");

		      		if ($popups){

		      		    $i = 1;
		      		    foreach($popups as $popup) {

		      		    	$color_portrait = wp_get_attachment_image_src($popup["color_portait"], "sidebar_image");
					    	$color_portrait = $color_portrait[0];

                         	$name = $popup["name"];

                                echo '<div class="boxes">';
                            	echo'<div id="dialog-'. $i++ .'" class="window">';

                                echo '<div class="the-body">';

                            if ($color_portrait) {
		      					echo '<img class="color-portrait" src="'. $color_portrait .'" alt="'. $name . '" /> ';
		      					  }

		      				    echo '<div class="text-elements">';
		      					echo '<h2>'. $name . '</h2>';
		      					echo '<p class="job-title">'. strip_tags($popup ['job_title']) .'</p>';
		      					echo  $popup ['biography'] ;
		      				    echo '</div>';#text-elements
		      				    echo '<a href="#" alt="Close window" title="Close window" class="close">Close</a>';
		      				    echo '</div>';
                                echo '</div>'; #dialog
                                echo'<div id="mask"></div>';
                                echo '</div>';   #boxes
                             	}


		      				}
					?>
						<!-- END MODAL WINDOW -->


							</section> <!-- end article section -->

							<footer>


							</footer> <!-- end article footer -->

						</article> <!-- end article -->


						<?php endwhile; ?>

						<?php else : ?>


						<?php endif; ?>

					</div> <!-- end #main -->


				</div> <!-- end #inner-content -->

			</div> <!-- end #content -->
		<div class="push"></div>
	</div><!--container-->

<?php get_footer(); ?>
