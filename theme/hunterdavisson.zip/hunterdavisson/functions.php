<?php
/*
Author: Eddie Machado
URL: htp://themble.com/bones/

This is where you can drop your custom functions or
just edit things like thumbnail sizes, header images,
sidebars, comments, ect.
*/

// Get Bones Core Up & Running!
require_once('library/bones.php');            // core functions (don't remove)

add_editor_style('library/css/custom-editor-style.css');



// Admin Functions (commented out by default)
// require_once('library/admin.php');         // custom admin functions

/************* THUMBNAIL SIZE OPTIONS *************/

function get_random_header($url){
$images = glob(get_template_directory() . '/images/headers/*');
$rando = $images[rand(0, count($images) - 1)];
  return $url . "/images/headers/" .   basename($rando);
}

/*
to add more sizes, simply copy a line from above
and change the dimensions & name. As long as you
upload a "featured image" as large as the biggest
set width or height, all the other sizes will be
auto-cropped.

To call a different size, simply change the text
inside the thumbnail function.

For example, to call the 300 x 300 sized image,
we would use the function:
<?php the_post_thumbnail( 'bones-thumb-300' ); ?>
for the 600 x 100 image:
<?php the_post_thumbnail( 'bones-thumb-600' ); ?>

You can change the names and dimensions to whatever
you like. Enjoy!
*/

/************* ACTIVE SIDEBARS ********************/

// Sidebars & Widgetizes Areas
function bones_register_sidebars() {
    register_sidebar(array(
    	'id' => 'sidebar1',
    	'name' => 'Sidebar 1',
    	'description' => 'The first (primary) sidebar.',
    	'before_widget' => '<div id="%1$s" class="widget %2$s">',
    	'after_widget' => '</div>',
    	'before_title' => '<h4 class="widgettitle">',
    	'after_title' => '</h4>',
    ));

        register_sidebar(array(
    	'id' => 'front-menu',
    	'name' => 'front menu',
    	'description' => 'The menu that appears in the content area on the front page.',
    	'before_widget' => '<div id="%1$s" class="widget %2$s">',
    	'after_widget' => '</div>',
    	'before_title' => '<h4 class="widgettitle">',
    	'after_title' => '</h4>',
    ));

    /*
    to add more sidebars or widgetized areas, just copy
    and edit the above sidebar code. In order to call
    your new sidebar just use the following code:

    Just change the name to whatever your new
    sidebar's id is, for example:

    register_sidebar(array(
    	'id' => 'sidebar2',
    	'name' => 'Sidebar 2',
    	'description' => 'The second (secondary) sidebar.',
    	'before_widget' => '<div id="%1$s" class="widget %2$s">',
    	'after_widget' => '</div>',
    	'before_title' => '<h4 class="widgettitle">',
    	'after_title' => '</h4>',
    ));

    To call the sidebar in your template, you can just copy
    the sidebar.php file and rename it to your sidebar's name.
    So using the above example, it would be:
    sidebar-sidebar2.php

    */
} // don't remove this bracket!


/************* SEARCH FORM LAYOUT *****************/

// Search Form
function bones_wpsearch($form) {
    $form = '<form role="search" method="get" id="searchform" action="' . home_url( '/' ) . '" >
    <label class="screen-reader-text" for="s">' . __('Search for:', 'bonestheme') . '</label>
    <input type="text" value="' . get_search_query() . '" name="s" id="s" placeholder="Search the Site..." />
    <input type="submit" id="searchsubmit" value="'. esc_attr__('Search') .'" />
    </form>';
    return $form;
} // don't remove this bracket!



/************* ADD FIRST AND LAST CLASSES TO WORDPRESS *****************/

function add_first_and_last($output) {
  $output = preg_replace('/class="menu-item/', 'class="first-menu-item menu-item', $output, 1);
  $output = substr_replace($output, 'class="last-menu-item menu-item', strripos($output, 'class="menu-item'), strlen('class="menu-item'));
  return $output;
}

add_filter('wp_nav_menu', 'add_first_and_last');

/***************************PERMISSIONS FOR EDITOR ROLE********************/

// get the the role object
$role_object = get_role( 'editor' );

// add $cap capability to this role object
$role_object->add_cap( 'edit_theme_options' );

$editor = get_role( 'editor' );
    $editor->add_cap( 'gravityforms_edit_forms' );
    $editor->add_cap( 'gravityforms_delete_forms' );
    $editor->add_cap( 'gravityforms_create_form' );
    $editor->add_cap( 'gravityforms_view_entries' );
    $editor->add_cap( 'gravityforms_edit_entries' );
    $editor->add_cap( 'gravityforms_delete_entries' );
    $editor->add_cap( 'gravityforms_view_settings' );
    $editor->add_cap( 'gravityforms_edit_settings' );
    $editor->add_cap( 'gravityforms_export_entries' );
    $editor->add_cap( 'gravityforms_view_entry_notes' );
    $editor->add_cap( 'gravityforms_edit_entry_notes' );

/*************************************EDITOR DROP DOWN****************************/
/*
Plugin Name: Custom Quick Styles
Plugin URI: http://www.speckygeek.com
Description: Add custom styles in your posts and pages content using TinyMCE WYSIWYG editor. The plugin adds a Styles dropdown menu in the visual post editor.
Based on TinyMCE Kit plug-in for WordPress

http://plugins.svn.wordpress.org/tinymce-advanced/branches/tinymce-kit/tinymce-kit.php

*/
/**
 * Apply styles to the visual editor
 */
add_filter('mce_css', 'tuts_mcekit_editor_style');
function tuts_mcekit_editor_style($url) {

    if ( !empty($url) )
        $url .= ',';

    // Retrieves the plugin directory URL and adds editor stylesheet
    // Change the path here if using different directories
    $url .= trailingslashit( get_template_directory_uri() ) . '/library/css/custom-editor-style.css';

    return $url;
}

// get user role
function get_user_role() {
	global $current_user;

	$user_roles = $current_user->roles;
	$user_role = array_shift($user_roles);

	return $user_role;
}

// redirect subscriber and file upload users to appropriate page
function login_redirect( $redirect_to, $request, $user  ) {
	if (is_array( $user->roles ) && in_array( 'subscriber', $user->roles)) {
		return "http://www.hunterdavisson.com/file-upload/";
	} elseif (is_array( $user->roles ) && in_array( 'file_upload_manager', $user->roles)) {
		return "http://www.hunterdavisson.com/wp-admin/users.php";
	} else {
		return admin_url();
	}
}
add_filter( 'login_redirect', 'login_redirect', 10, 3 );


// block file upload role from editing any pages exculing the file upload page
function block_edit( $content, $post_id) {
  $urole = get_user_role();
  if (($urole == "file_upload_manager") && ($post_id!="1212") ) {
  	wp_die( '<pre>No Edit Access</pre>' );
  } else {
  	return $content;
  }
}
add_filter( 'content_edit_pre', 'block_edit', 10, 2 );


// new file upload manager role
add_role('file_upload_manager', 'File Upload Manager', array(
    'manage_user_groups' => true,
));
$role2 =& get_role('file_upload_manager');
$role2->remove_cap('activate_plugins');
$role2->remove_cap('delete_others_pages');
$role2->remove_cap('delete_others_posts');
$role2->remove_cap('delete_pages');
$role2->remove_cap('delete_plugins');
$role2->remove_cap('delete_posts');
$role2->remove_cap('delete_private_pages');
$role2->remove_cap('delete_private_posts');
$role2->remove_cap('delete_published_pages');
$role2->remove_cap('delete_published_posts');
$role2->remove_cap('edit_dashboard');
$role2->remove_cap('edit_files');
$role2->add_cap('edit_others_pages');
$role2->add_cap('edit_others_posts');
$role2->add_cap('edit_pages');
$role2->add_cap('edit_posts');
$role2->add_cap('edit_private_pages');
$role2->add_cap('edit_private_posts');
$role2->add_cap('edit_published_pages');
$role2->add_cap('edit_published_posts');
$role2->add_cap('edit_theme_options');
$role2->remove_cap('export');
$role2->remove_cap('import');
$role2->add_cap('list_users');
$role2->add_cap('manage_categories');
$role2->add_cap('manage_links');
$role2->add_cap('manage_options');
$role2->remove_cap('moderate_comments');
$role2->remove_cap('promote_users');
//$role2->add_cap('publish_pages');
$role2->remove_cap('publish_pages');
$role2->add_cap('publish_posts');
$role2->add_cap('read_private_pages');
$role2->add_cap('read_private_posts');
$role2->add_cap('read');
$role2->add_cap('remove_users');
$role2->remove_cap('switch_themes');
$role2->add_cap('upload_files');
$role2->remove_cap('create_product');
$role2->remove_cap('update_core');
$role2->remove_cap('update_plugins');
$role2->remove_cap('update_themes');
$role2->remove_cap('install_plugins');
$role2->remove_cap('install_themes');
$role2->remove_cap('delete_themes');
$role2->add_cap('edit_plugins');
$role2->add_cap('edit_themes');
$role2->add_cap('edit_users');
$role2->add_cap('create_users');
$role2->add_cap('delete_users');
$role2->add_cap('unfiltered_html');
$role2->add_cap('manage_user_groups');

// filter what user roles the file upload manager can add
add_filter( 'editable_roles', 'filter_roles' );
function filter_roles( $roles )
{
    $user = wp_get_current_user();
    if( in_array( 'editor', $user->roles ) || in_array( 'file_upload_manager', $user->roles ) )
    {
        $tmp = array_keys( $roles );
        foreach( $tmp as $r )
        {
            if( 'subscriber' == $r ) continue;
            unset( $roles[$r] );
        }
    }
    return $roles;
}

// filter what user roles dropdown on create new user screen for file upload manager role
add_action('pre_user_query','subscriber_pre_user_query');
function subscriber_pre_user_query($user_search) {
  $role = get_user_role();
  if ($role == 'file_upload_manager') {
    global $wpdb;

  	$user_search->query_where = str_replace('WHERE 1=1', "WHERE 1=1 AND {$wpdb->users}.ID IN (SELECT wp_usermeta.user_id FROM $wpdb->usermeta WHERE wp_usermeta.meta_key = 'wp_capabilities' AND wp_usermeta.meta_value LIKE '%subscriber%')",	$user_search->query_where);
  }
}

// hide add new page link for file upload manager role
add_action('admin_head', 'hide_posts_pages');
function hide_posts_pages() {
    $role = get_user_role();

    If($role == 'file_upload_manager') {
        ?>
        <style>

           .add-new-h2 {
                display:none;
           }


        </style>
        <?php
    }
}


// only show file upload page in page list for file upload manager role
add_action( 'pre_get_posts' ,'only_file_upload_page' );
function only_file_upload_page($query ) {

	global $pagenow;

	$role = get_user_role();

	if($role == 'file_upload_manager') {

		if( 'edit.php' == $pagenow && ( get_query_var('post_type') && 'page' == get_query_var('post_type') ) )
			$query->set( 'post__in', array(1212) );

	}

	return $query;
}










/**
 * Add "Styles" drop-down content or classes
 */
function tuts_mcekit_editor_settings($settings) {
    if (!empty($settings['theme_advanced_styles']))
        $settings['theme_advanced_styles'] .= ';';
    else
        $settings['theme_advanced_styles'] = '';

    /**
     * Add styles in $classes array.
     * The format for this setting is "Name to display=class-name;".
     * More info: http://wiki.moxiecode.com/index.php/TinyMCE:Configuration/theme_advanced_styles
     *
     * To be allow translation of the class names, these can be set in a PHP array (to keep them
     * readable) and then converted to TinyMCE's format. You will need to replace 'textdomain' with
     * your theme's textdomain.
     */
    $classes = array(
        __('Emergency','Emergency') => 'emergency',
        __('Phone-number','Phone-number') => 'phone-number',
        __('Clr','Clr') =>'clr'
    );

    $class_settings = '';
    foreach ( $classes as $name => $value )
        $class_settings .= "{$name}={$value};";

    $settings['theme_advanced_styles'] .= trim($class_settings, '; ');
    return $settings;
}

add_filter('tiny_mce_before_init', 'tuts_mcekit_editor_settings');

remove_action('template_redirect', 'redirect_canonical');
