<?php get_header(); ?>
<div class="page-header subpage-header header-filter clear-filter"  data-parallax="true" style="background-image: url('<?php bloginfo('template_url'); ?>/images/tillicum3.jpg');">
        <div class="container">
         <div class="row">
           <div class="col-md-12">
             <h1 style='color: white'><?php the_title(); ?></h1>
           </div>
         </div>
       </div>
      </div>
  </div>
  <div class="main main-raised">

				    <div class="container"  style='padding-top: 40px; padding-bottom: 100px'>


						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<h2><?php the_title(); ?></h2>
							<?php the_content(); ?>
              <div class="section section-tabs" style='background-color: #fff; padding: 30px'>
              <div class="container">
              <div class="row">
							<?php
							$pages = get_pages( array('child_of'=>$post->ID, 'sort_column' => 'menu_order') );
							foreach($pages as $page){?>

                  <div class="col-md-3">
                  <div class="card card-blog" style='margin-top: 30px; box-shadow: 0 0px 0px 0 rgba(0, 0, 0, 0.0), 0 0px 0px 0px rgba(0, 0, 0, 0.0), 0 0px 0px 0 rgba(0, 0, 0, 0.0)'>
                  <div class="card-header card-header-image">
                    <a title="<?php the_title(); ?>" href="<?php echo get_permalink($page->ID); ?>">
                      <img class="img portfolio_img" src="<?php the_field('featured_image', $page->ID);?>" >
                      <div class="card-title">
                        <?php echo get_the_title($page->ID); ?>
                      </div>
                    </a>
                  </div>
                  </div>
                </div>

							<?php };?>
							</div>
							</div>
							</div>



						<?php endwhile; else: ?>

						<article id="post-not-found">
						    <header>
						    	<h1>Not Found</h1>
						    </header>
						    <section class="post-content">
						    	<p>Sorry, but the requested resource was not found on this site.</p>
						    </section>
						    <footer>
						    </footer>
						</article>

						<?php endif; ?>

					</div> <!-- end #main -->

				</div> <!-- end #inner-content -->



				<?php get_footer(); ?>
